package com.urambank.uram.controller;

import com.urambank.uram.dto.CurrencyExchangeDTO;
import com.urambank.uram.dto.AccountDTO;
import com.urambank.uram.service.TradeService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequiredArgsConstructor
public class TradeController {

    private static final Logger logger = LoggerFactory.getLogger(TradeController.class);
    private final TradeService tradeService;

    @GetMapping("/exchangeList")
    public ResponseEntity<List<CurrencyExchangeDTO>> getExchangeHistory() {
        logger.info("<<< getExchangeHistory >>>");
        return ResponseEntity.ok(tradeService.getExchangeHistory());
    }

    @GetMapping("/exchange")
    public ResponseEntity<Map<String, Object>> getExchangeDetails(@PathVariable int accountNo) {
        logger.info("<<< getExchangeDetails >>>");
        return ResponseEntity.ok(tradeService.getExchangeDetails(accountNo));
    }

    @PostMapping("/exchange")
    public ResponseEntity<Boolean> verifyPassword(@RequestParam int userNo, @RequestParam String password) {
        logger.info("<<< verifyPassword >>>");
        boolean isValid = tradeService.verifyPassword(userNo, password);
        return ResponseEntity.ok(isValid);
    }
}