package com.urambank.uram.repository;

import com.urambank.uram.dto.AccountDTO;
import com.urambank.uram.entities.AccountEntity;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AccountRepository extends JpaRepository<AccountEntity, Integer> {

    List<AccountEntity> findAll();
}
