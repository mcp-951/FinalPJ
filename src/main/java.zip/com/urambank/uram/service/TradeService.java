package com.urambank.uram.service;

import com.urambank.uram.dto.AccountDTO;
import com.urambank.uram.dto.CurrencyExchangeDTO;
import com.urambank.uram.dto.PickUpPlaceDTO;
import com.urambank.uram.entities.AccountEntity;
import com.urambank.uram.entities.CurrencyExchangeEntity;
import com.urambank.uram.entities.PickUpPlaceEntity;
import com.urambank.uram.entities.ProductEntity;
import com.urambank.uram.entities.User;
import com.urambank.uram.repository.AccountRepository;
import com.urambank.uram.repository.CurrencyExchangeRepository;
import com.urambank.uram.repository.PickUpPlaceRepository;
import com.urambank.uram.repository.ProductRepository;
import com.urambank.uram.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class TradeService {

    private final CurrencyExchangeRepository currencyExchangeRepository;
    private final AccountRepository accountRepository;
    private final ProductRepository productRepository;
    private final PickUpPlaceRepository pickUpPlaceRepository;
    private final UserRepository userRepository;

    public List<CurrencyExchangeDTO> getExchangeHistory() {
        List<CurrencyExchangeEntity> entities = currencyExchangeRepository.findAll();
        return entities.stream().map(entity -> CurrencyExchangeDTO.builder()
                .tradeNo(entity.getTradeNo())
                .userNo(entity.getUserNo())
                .accountNo(entity.getAccountNo())
                .selectCountry(entity.getSelectCountry())
                .exchangeRate(entity.getExchangeRate())
                .tradeDate(entity.getTradeDate())
                .pickupPlace(entity.getPickupPlace())
                .tradePrice(entity.getTradePrice())
                .tradeAmount(entity.getTradeAmount())
                .receiveDate(entity.getReceiveDate())
                .build()).collect(Collectors.toList());
    }

    public Map<String, Object> getExchangeDetails(int accountNo) {
        AccountEntity account = accountRepository.findById(accountNo)
                .orElseThrow(() -> new RuntimeException("Account not found"));

        ProductEntity product = productRepository.findById(account.getProductNo())
                .orElseThrow(() -> new RuntimeException("Product not found"));

        AccountDTO accountDTO = AccountDTO.builder()
                .accountNumber(account.getAccountNumber())
                .productNo(account.getProductNo())
                .productNo(Integer.parseInt(product.getProductName()))
                .build();

        List<PickUpPlaceDTO> pickupPlaces = pickUpPlaceRepository.findAll()
                .stream()
                .map(entity -> new PickUpPlaceDTO(entity.getPickUpPlaceName()))
                .collect(Collectors.toList());

        Map<String, Object> response = new HashMap<>();
        response.put("account", accountDTO);
        response.put("pickupPlaces", pickupPlaces);
        return response;
    }

    public boolean verifyPassword(int userNo, String inputPassword) {
        User user = userRepository.findById(userNo)
                .orElseThrow(() -> new RuntimeException("User not found"));
        return user.getPassword().equals(inputPassword);
    }
}