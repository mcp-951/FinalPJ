package com.urambank.uram.repository;

public interface

DepositRepository {
}
