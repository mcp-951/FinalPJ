package com.urambank.uram.repository;

import com.urambank.uram.entities.LoanJoinEntity;
import org.springframework.data.jpa.repository.JpaRepository;



public interface LoanJoinRepository extends JpaRepository<LoanJoinEntity, Long> {

}

