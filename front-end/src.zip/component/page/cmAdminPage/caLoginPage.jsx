import React from "react";

function CommunityAdminDTO(){

    return(
        <form action="">
            
        </form>
    )
}

export default CommunityAdminDTO;