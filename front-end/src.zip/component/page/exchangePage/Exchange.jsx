import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';

import '../../../resource/css/exchange/Exchange.css';
import Footer from '../../util/Footer';
import axios from 'axios';

const Exchange = () => {
    const [currency, setCurrency] = useState('');
    const [amount, setAmount] = useState('');
    const [rate, setRate] = useState(0);
    const [requiredWon, setRequiredWon] = useState(0);
    const [date, setDate] = useState('');
    const [branch, setBranch] = useState('');
    const [account, setAccount] = useState('');
    const [password, setPassword] = useState('');
    const [isPasswordConfirmed, setIsPasswordConfirmed] = useState(false);
    const [branches, setBranches] = useState([]);
    const [accounts, setAccounts] = useState([]);
    const passwordInputRef = useRef(null);
    const navigate = useNavigate();
    
    // 계좌 정보와 지점 정보 가져오기 (한 번에)
    useEffect(() => {
        const accountNo = 1; // 실제 계좌번호로 대체 필요
        axios.get(`/exchange`)
            .then(response => {
                const { account, pickupPlaces } = response.data;
                setAccounts([account]);
                setBranches(pickupPlaces.map(place => place.pickUpPlaceName));
            })
            .catch(error => {
                console.error("지점 및 계좌 정보를 가져오는 중 오류 발생:", error);
            });
    }, []);

    // 나라 선택 시 환율 정보 자동으로 가져오기
    useEffect(() => {
        if (currency) {
            axios.get(`https://api.exchangerate-api.com/v4/latest/${currency}`)
                .then(response => {
                    setRate(response.data.rates.KRW);
                })
                .catch(error => {
                    console.error('환율 정보를 가져오는 중 오류 발생:', error);
                });
        }
    }, [currency]);

    // 신청 버튼 클릭 시 환전 신청 처리
    const handleSubmit = () => {
        if (!isPasswordConfirmed) {
            alert('비밀번호를 확인하세요.');
            return;
        }
        if (!currency || !amount || !date || !branch || !account) {
            alert('모든 항목을 입력해주세요.');
            return;
        }

        const confirmResult = window.confirm('환전 하시겠습니까?');
        if (confirmResult) {
            const exchangeDetails = {
                userNo: 1,
                accountNo: account,
                selectCountry: currency,
                exchangeRate: rate,
                tradeDate: new Date().toISOString().split('T')[0],
                pickupPlace: branch,
                tradePrice: requiredWon,
                tradeAmount: amount,
                receiveDate: date
            };

            axios.post('/exchange', exchangeDetails)
                .then(response => {
                    if (response.status === 200) {
                        navigate('/exchange-result', {
                            state: {
                                message: `${date}에 ${branch}에 방문 해주세요.`
                            }
                        });
                    } else {
                        alert('환전 신청에 실패했습니다.');
                    }
                })
                .catch(error => {
                    console.error('환전 신청 중 오류 발생:', error);
                    alert('환전 신청에 실패했습니다.');
                });
        }
    };

    // 비밀번호 확인 처리
    const PwdSubmit = () => {
        axios.post('/exchange', null, {
            params: { userNo: 1, password: password }  // 실제 사용자 번호로 대체 필요
        })
        .then(response => {
            if (response.data) {
                alert("비밀번호가 일치합니다");
                setIsPasswordConfirmed(true);
            } else {
                alert('비밀번호 불일치');
                passwordInputRef.current.focus();
            }
        })
        .catch(error => {
            console.error('비밀번호 확인 중 오류 발생:', error);
            alert('비밀번호 확인에 실패했습니다.');
        });
    };

    // 통화 종류 변경 핸들러
    const handleCurrencyChange = (e) => {
        setCurrency(e.target.value);
    };

    // 환전 금액 변경 핸들러
    const handleAmountChange = (e) => {
        setAmount(e.target.value);
        setRequiredWon(e.target.value * rate);
    };

    return (
        <div className="exchange-container">
            <h2>환전 신청</h2>
            <div className="exchange-row" style={{ marginTop: '50px' }}>
                <div className="exchange-column">
                    <label className='exlabel'>통화 종류</label>
                    <select className="ex" value={currency} onChange={handleCurrencyChange}>
                        <option value="">선택하세요</option>
                        <option value="USD">미국 (USD)</option>
                        <option value="JPY">일본 (JPY)</option>
                        <option value="CNY">중국 (CNY)</option>
                        <option value="EUR">유로 (EUR)</option>
                    </select>
                </div>
                <div className="exchange-column">
                    <label className='exlabel'>환전 금액</label>
                    <input className="ex" type="number" value={amount} onChange={handleAmountChange} />
                </div>
                <div className="exchange-column">
                    <label className='exlabel'>현재 환율</label>
                    <input className="ex" type="text" value={rate} readOnly />
                </div>
                <div className="exchange-column">
                    <label className='exlabel'>필요 원화</label>
                    <input className="ex" type="text" value={requiredWon} readOnly />
                </div>
            </div>
            <div className="exchange-row" style={{ marginTop: '50px' }}>
                <div className="exchange-column-vertical">
                    <label className='exlabel'>수령일</label>
                    <input className="ex" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
                    <label className='exlabel' style={{ marginTop: '20px' }}>수령 지점</label>
                    <select className="ex" value={branch} onChange={(e) => setBranch(e.target.value)}>
                        <option value="">지점 선택</option>
                        {branches.map((branch, index) => (
                            <option key={index} value={branch}>
                                {branch}
                            </option>
                        ))}
                    </select>
                </div>
                <div className="exchange-column-vertical">
                    <label className='exlabel'>출금 계좌</label>
                    <select className="ex" value={account} onChange={(e) => setAccount(e.target.value)}>
                        <option value="">계좌 선택</option>
                        {accounts.map((account, index) => (
                            <option key={index} value={account.accountNumber}>
                                {account.accountNumber} - {account.productName}
                            </option>
                        ))}
                    </select>
                    <label className='exlabel' style={{ marginTop: '20px' }}>비밀번호</label>
                    <div className="password-container">
                        <input
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="password-input"
                            ref={passwordInputRef}
                        />
                        <button className='password-button' onClick={PwdSubmit} style={{ marginBottom: '50px' }}>확인</button>
                    </div>
                </div>
            </div>
            <button className='OkBtn' onClick={handleSubmit} style={{ marginBottom: '50px' }}>신청</button>

            <Footer />
        </div>
    );
};

export default Exchange;
