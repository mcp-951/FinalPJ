package com.urambank.uram;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UramApplicationTests {

	@Test
	void contextLoads() {
	}

}
